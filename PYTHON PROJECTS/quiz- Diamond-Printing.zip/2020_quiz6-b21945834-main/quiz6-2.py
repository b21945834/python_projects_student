import sys
s = int(sys.argv[1])
liste = [(2*i-1)* "*" for i in range(1,s+1)]
liste2 = [(2*i-1)* "*" for i in range(s-1,0,-1)]
liste = liste + liste2
for i in range(len(liste)):
    while len(liste[i]) != 2*s-1:
        liste[i] = " " + liste[i] + " "
for i in liste:
    print(*i)
