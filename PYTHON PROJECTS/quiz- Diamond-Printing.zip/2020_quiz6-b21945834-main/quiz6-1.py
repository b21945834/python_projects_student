import sys
sys = int(sys.argv[1])
s = 1
liste = []
sayac = 0
def diaomond(s):
    if s == 0:
        return liste
    elif s == sys:
        liste.append((2*s-1)* "*")
        global sayac
        sayac += 1
        return diaomond(s-1)
    elif sys > s:
        liste.append((2*s-1)* "*")
        if sayac == 0:
            return diaomond(s+1)
        else:
            return diaomond(s-1)

diaomond(1)
for index in range(len(liste)):
    while len(liste[index]) != 2*sys-1:
        liste[index] = " " + liste[index] + " "
for e in liste:
    print(*e)