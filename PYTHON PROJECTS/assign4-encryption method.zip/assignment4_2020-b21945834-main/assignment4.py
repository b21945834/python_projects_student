import sys
try: #1
    assert len(sys.argv) == 5
except AssertionError:
    print("Parameter number error")
    exit()
try: #2
    assert sys.argv[1] in ["dec","enc"]
except AssertionError:
    print("Undefined parameter error")
    exit()
try: #3
    f = open(sys.argv[3], "r+")
except FileNotFoundError:
    print("Input file not found error")
    exit()
try: #4
    assert sys.argv[3][-3:] == "txt"
except AssertionError:
    print("The input file could not be read error")
    exit()
f = open(sys.argv[3], "r+")
try: #5
    assert f.readline() != ""
except AssertionError:
    print("Input file is empty error")
    exit()
kucukharf = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
buyukharf = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
f = open(sys.argv[3],"r+")
for harf in f.readline(): #6
    if sys.argv[1] == "enc":
        try:
            assert harf in kucukharf + [" "] or harf in buyukharf + [" "]
        except AssertionError:
            print("Invalid character in input file error")
            exit()
    elif sys.argv[1] == "dec":
        try:
            assert harf in [",","1","2","3","4","5","6","7","8","9","0"]
        except AssertionError:
            print("Invalid character in input file error")
            exit()

try:#7
    k = open(sys.argv[2],"r+")
except FileNotFoundError:
    print("Key file not found error")
    exit()
try: #8
    assert sys.argv[2][-3:] == "txt"
except AssertionError:
    print("The key file could not be read")
    exit()
try:
    assert k.readline() != ""
except AssertionError:
        print("Key file is empty")
        exit()
k = open(sys.argv[2],"r+")
for line in k:
    for sayi in line:
        try:
            assert list(sayi)[0] in [",","1","2","3","4","5","6","7","8","9","0","\n","-"]
        except AssertionError:
            print("Invalid character in key file error")
            exit()
kharfsayi = {harf:sayi for sayi, harf in enumerate(kucukharf, 1)}
bharfsayi = {harf:sayi for sayi, harf in enumerate(buyukharf, 1)}
decdic = {v: k for k, v in bharfsayi.items()}
kharfsayi[" "] = 27
bharfsayi[" "] = 27

if sys.argv[1] == "enc":
    # HARFLERİN SAYI KARŞILIKLARINI LİSTEYE ALIYORUM: INPUTLIST
    inputlist = []
    f = open(sys.argv[3],"r+")
    k = open(sys.argv[2],"r+")
    for line in f:
        for h in list(line):
            if h in kharfsayi:
                inputlist.append(kharfsayi[h])
            elif h in bharfsayi:
                inputlist.append(bharfsayi[h])
    k = open(sys.argv[2],"r+")
    # N: NxN matrix, kaç birimlik?
    n = len(k.readline().split(","))
    # SONUNA GEREKLİYSE BOŞLUK KARŞILIĞINI EKLİYORUM.
    while len(inputlist) % n != 0:
        inputlist.append(27)

    ilk = []
    inputmatrix = []
    # ÇARPIM İŞLEMİ İÇİN GEREKLİ HALE GETİRİYORUM.
    for e in inputlist:
        ilk.append([e])
    while len(ilk) >= n:
        inputmatrix.append(ilk[:n])
        del ilk[:n]
    #
    keymatrix = []
    f = open(sys.argv[3],"r+")
    k = open(sys.argv[2],"r+")
    # RAKAMLARI INT'E CEVIRIP LISTEYE EKLİYORUM
    for row in k:
        if "\n" in row:
            row = row.rstrip("\n")
        row = row.split(",")
        for i in range(len(row)):
            row[i] = int(row[i])
        keymatrix.append(row)
    #RESULT BELİRLEME FONKSİYONU
    resultliste = []
    def resultbelirleme(n):
        global resultliste
        resultliste = []
        rl = list(n*"0")
        for e in rl:
            resultliste.append([int(e)])
        return resultliste
    outputlist = []
    # MATRIX CARPIMI
    for pair in inputmatrix:
        result = resultbelirleme(n)
        for i in range(len(keymatrix)):
            for j in range(len(pair[0])):
                for k in range(len(pair)):
                    result[i][j] += keymatrix[i][k] * pair[k][j]
        outputlist.append(result)

    outputliststring = ""
    for p in outputlist:
        for x in p:
            outputliststring += str(x[0]) + ","
    if outputliststring[-1] == ",":
        outputliststring = outputliststring[:-1]

    o = open(sys.argv[4], "w+")
    o.write(outputliststring)
    o.close()
    f.close()
#encoding sonu
#decoding başı
if sys.argv[1] == "dec":
    matrix = []
    k = open(sys.argv[2], "r+")
    for row in k:
        if "\n" in row:
            row = row.rstrip("\n")
        row = row.split(",")
        for i in range(len(row)):
            row[i] = int(row[i])
        matrix.append(row)

    for x in matrix:
        n = len(x)
    x = 0
    birimmatrix = []
    tempbirim = []
    while x <= n - 1:
        tempbirim = []
        t = 0
        if x > 0:
            while t != x:
                tempbirim.append(0)
                t += 1
        tempbirim.insert(x, 1)
        while len(tempbirim) != n:
            tempbirim.append(0)
        birimmatrix.append(tempbirim)
        x += 1

    f = open(sys.argv[3],"r+")

    ilk = []
    decmatrix = []
    decodethis = f.readline().split(",")
    while len(decodethis) % n != 0:
        decodethis.append("27")
    for e in decodethis:
        ilk.append([int(e)])
    while len(ilk) >= n:
        decmatrix.append(ilk[:n])
        del ilk[:n]


    capraz = 0

    while capraz <= n - 1:
        satir = 0
        sutun = 0
        a = 0
        b = 0
        if matrix[0 + capraz][0 + capraz] != 0:
            bolen = matrix[0 + capraz][0 + capraz]
        else:
            while sutun <= n - 1:
                while capraz + b <= n - 1 and matrix[capraz + b][sutun + capraz] == 0:
                    b += 1
                    if capraz + b > n - 1:
                        while capraz + b != 0:
                            b = b - 1
                matrix[satir + capraz][sutun] += matrix[capraz + b][sutun]
                birimmatrix[satir + capraz][sutun] += birimmatrix[capraz + b][sutun]
                sutun += 1
            sutun = 0
            bolen = matrix[satir + capraz][sutun + capraz]

        while sutun + capraz <= n - 1 and satir + capraz <= n - 1 and a <= n - 1:
            matrix[capraz][sutun + capraz] = matrix[satir + capraz][sutun + capraz] / bolen
            sutun += 1
        while a <= n - 1:
            birimmatrix[capraz][a] = birimmatrix[satir + capraz][a] / bolen
            a += 1
        sutun = 0
        satir = 0

        if matrix[satir] != matrix[0 + capraz]:
            carpan = matrix[satir][sutun + capraz] / matrix[0 + capraz][0 + capraz]
        else:
            satir += 1
            carpan = matrix[satir][sutun + capraz] / matrix[0 + capraz][0 + capraz]
        a = 0

        while sutun + capraz <= n - 1 and satir <= n - 1:
            matrix[satir][sutun + capraz] = matrix[satir][sutun + capraz] - matrix[0 + capraz][sutun + capraz] * carpan
            sutun += 1
            while a <= n - 1:
                birimmatrix[satir][a] = birimmatrix[satir][a] - birimmatrix[0 + capraz][a] * carpan
                a += 1
            if sutun + capraz >= n:
                sutun = 0
                satir += 1
                a = 0
                if satir != n:
                    if matrix[satir] != matrix[0 + capraz]:
                        carpan = matrix[satir][sutun + capraz] / matrix[0 + capraz][0 + capraz]
                    else:
                        satir += 1
                        if satir != n:
                            carpan = matrix[satir][sutun + capraz] / matrix[0 + capraz][0 + capraz]
        capraz += 1

    tersmatrix = birimmatrix
    for xx in range(len(tersmatrix)):
        for yy in range(len(tersmatrix[xx])):
            tersmatrix[xx][yy] = round(tersmatrix[xx][yy])

    def resultbelirleme(n):
        global resultliste
        resultliste = []
        rl = list(n * "0")
        for e in rl:
            resultliste.append([int(e)])
        return resultliste

    outputlist = []
    for pair in decmatrix:
        result = resultbelirleme(n)
        for i in range(len(tersmatrix)):
            for j in range(len(pair[0])):
                for k in range(len(pair)):
                    result[i][j] = tersmatrix[i][k] * pair[k][j] + result[i][j]
        outputlist.append(result)

    outputliststring = ""
    decdic[27] = " "
    for p in outputlist:
        for x in p:
            outputliststring += decdic[x[0]]
    while outputliststring[:-1] == " ":
        outputliststring = outputliststring[:-1]
    w = open(sys.argv[4],"w+")
    w.write(outputliststring)
    w.close()
    f.close()


























