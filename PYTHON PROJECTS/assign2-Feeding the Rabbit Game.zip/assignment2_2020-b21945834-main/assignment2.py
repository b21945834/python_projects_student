map = input("Please enter feeding map as a list:")
map = map.strip("]") + "]"
map = "[" + map.strip("[")
map = map.replace("], ", "] , ")
map = map.split(" , ")

for e in range(len(map)):
    map[e] = map[e].strip("]").strip("[")
    map[e] = map[e].split(", ")

for x in range(len(map)):
    for t in range(len(map[x])):
        map[x][t] = map[x][t].strip("’").strip("'")

dir = input("Please enter direction of movements as a list:")
dir = dir.strip("[").strip("]").replace("'","").replace("’","").split(", ")

for x in range(len(map)):
    for y in range(len(map[x])):
        if map[x][y] == "*":
            break
    if map[x][y] == "*":
        break
print("Your board is:")
for s in range(len(map)):
    print(*map[s])


points = 0
for g in dir:
    if g == "U" and x != 0:
        if map[x-1][y] != "W":
            if map[x-1][y] == "A":
                points = points + 5
                map[x-1][y] = "*"
                map[x][y] = "X"
                x = x - 1
            elif map[x-1][y] == "C":
                points = points + 10
                map[x-1][y] = "*"
                map[x][y] = "X"
                x = x-1
            elif map[x-1][y] == "M":
                points = points - 5
                map[x-1][y] = "*"
                map[x][y] = "X"
                x = x - 1
            elif map[x-1][y] == "P":
                map[x-1][y] = "*"
                map[x][y] = "X"
                x = x-1
                break
            elif map[x-1][y] == "X":
                map[x-1][y] = "*"
                map[x][y] = "X"
                x = x-1
    elif g == "D" and x != (len(map)-1):
        if map[x+1][y] != "W":
            if map[x+1][y] == "C":
                points = points + 10
                map[x+1][y] = "*"
                map[x][y] = "X"
                x = x + 1
            elif map[x+1][y] == "A":
                points = points + 5
                map[x+1][y] = "*"
                map[x][y] = "X"
                x = x + 1
            elif map[x+1][y] == "M":
                points = points - 5
                map[x+1][y] = "*"
                map[x][y] = "X"
                x = x + 1
            elif map[x+1][y] == "X":
                map[x+1][y] = "*"
                map[x][y] = "X"
                x = x + 1
            elif map[x+1][y] == "P":
                map[x+1][y] = "*"
                map[x][y] = "X"
                x = x + 1
                break
    elif g == "L" and y != 0:
        if map[x][y-1] != "W":
            if map[x][y-1] == "C":
                points = points + 10
                map[x][y-1] = "*"
                map[x][y] = "X"
                y = y - 1
            elif map[x][y-1] == "A":
                points = points + 5
                map[x][y-1] = "*"
                map[x][y] = "X"
                y = y - 1
            elif map[x][y-1] == "M":
                points = points - 5
                map[x][y-1] = "*"
                map[x][y] = "X"
                y = y - 1
            elif map[x][y-1] == "P":
                map[x][y-1] = "*"
                map[x][y] = "X"
                y = y - 1
                break
            elif map[x][y-1] == "X":
                map[x][y-1] = "*"
                map[x][y] = "X"
                y = y - 1
    elif g == "R" and y != (len(map[x]) - 1):
        if map[x][y+1] != "W":
            if map[x][y+1] == "C":
                points = points + 10
                map[x][y+1] = "*"
                map[x][y] = "X"
                y = y + 1
            elif map[x][y+1] == "A":
                points = points + 5
                map[x][y+1] = "*"
                map[x][y] = "X"
                y = y + 1
            elif map[x][y+1] == "M":
                points = points - 5
                map[x][y+1] = "*"
                map[x][y] = "X"
                y = y + 1
            elif map[x][y+1] == "P":
                map[x][y+1] = "*"
                map[x][y] = "X"
                y = y+1
                break
            elif map[x][y+1] == "X":
                map[x][y+1] = "*"
                map[x][y] = "X"
                y = y + 1

print("Your output should be like this:")
for s in range(len(map)):
    print(*map[s])
print("Your score is:", points)


