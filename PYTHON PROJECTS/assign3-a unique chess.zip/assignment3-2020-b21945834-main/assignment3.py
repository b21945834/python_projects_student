f=open("input.txt", "r")
commands=[[line.split()] for line in f.readlines()]
f.close()
harita = [
    ["R1", "N1", "B1", "QU", "KI", "B2", "N2", "R2"],
    ["P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8"],
    ["  ", "  ", "  ", "  ", "  ", "  ", "  ", "  "],
    ["  ", "  ", "  ", "  ", "  ", "  ", "  ", "  "],
    ["  ", "  ", "  ", "  ", "  ", "  ", "  ", "  "],
    ["  ", "  ", "  ", "  ", "  ", "  ", "  ", "  "],
    ["p1", "p2", "p3", "p4", "p5", "p6", "p7", "p8"],
    ["r1", "n1", "b1", "qu", "ki", "b2", "n2", "r2"]]
def sifirlama():
    global harita
    harita =   [
            ["R1", "N1", "B1", "QU", "KI", "B2", "N2", "R2"],
            ["P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8"],
            ["  ", "  ", "  ", "  ", "  ", "  ", "  ", "  "],
            ["  ", "  ", "  ", "  ", "  ", "  ", "  ", "  "],
            ["  ", "  ", "  ", "  ", "  ", "  ", "  ", "  "],
            ["  ", "  ", "  ", "  ", "  ", "  ", "  ", "  "],
            ["p1", "p2", "p3", "p4", "p5", "p6", "p7", "p8"],
            ["r1", "n1", "b1", "qu", "ki", "b2", "n2", "r2"]]
data = {}
moveliste = []
movedata= {}
def konumupdate():
    global movedata
    for i in range(1,9):
        movedata["1%d" % i] = harita[8-i][0]
    for i in range(1,9):
        movedata["2%d" % i] = harita[8-i][1]
    for i in range(1,9):
        movedata["3%d" % i] = harita[8-i][2]
    for i in range(1,9):
        movedata["4%d" % i] = harita[8-i][3]
    for i in range(1,9):
        movedata["5%d" % i] = harita[8-i][4]
    for i in range(1,9):
        movedata["6%d" % i] = harita[8-i][5]
    for i in range(1,9):
        movedata["7%d" % i] = harita[8-i][6]
    for i in range(1,9):
        movedata["8%d" % i] = harita[8-i][7]

for i in range(8,0,-1):
    data["a%d" % i] = "1%i" % i
for i in range(8,0,-1):
    data['b%d' % i] = "2%i" % i
for i in range(8,0,-1):
    data['c%d' % i] = "3%i" % i
for i in range(8,0,-1):
    data['d%d' % i] = "4%i" % i
for i in range(8,0,-1):
    data['e%d' % i] = "5%i" % i
for i in range(8,0,-1):
    data['f%d' % i] = "6%i" % i
for i in range(8,0,-1):
    data['g%d' % i] = "7%i" % i
for i in range(8,0,-1):
    data['h%d' % i] = "8%i" % i
newdata = dict((v, k) for k, v in data.items())
k = 0
l = 0
konumupdate()
beyazlar = ["r1","n1","b1","qu","ki","b2","n2","r2","p1","p2","p3","p4","p5","p6","p7","p8"]
siyahlar = ["R1","N1","B1","QU","KI","B2","N2","R2","P1","P2","P3","P4","P5","P6","P7","P8"]
def initialize():
    sifirlama()
    print("> initialize")
    print("-----------------------")
    for e in harita:
        print(*e)
    print("-----------------------")
def bulucu():
    global k
    global l
    for k in range(len(harita)):
        for l in range(len(harita[k])):
            if e[0][1] == harita[k][l]:
                break
        if e[0][1] == harita[k][l]:
            break
def showmoves():
    global k
    movelist()
    global moveliste
    moveliste.sort()
    for konum in moveliste:
        c = int(list(data[konum])[0])
        d = int(list(data[konum])[1])
        if harita[8-d][c-1] in ["ki","KI"]:
            moveliste.remove(konum)
    if len(moveliste) != 0:
        print("> showmoves", e[0][1])
        print(*moveliste)
    else:
        print("> showmoves", e[0][1])
        print("FAILED")

def movelist():
    bulucu()
    global siyahlar
    global beyazlar
    x = 1
    global moveliste
    global k
    if e[0][1] in ["p1","p2","p3","p4","p5","p6","p7","p8"]:          #BEYAZ PİYON
        if harita[k-1][l] not in beyazlar:
            moveliste.append(newdata[str(l + 1) + str(8 - k+1)])
    elif e[0][1] in ["P1","P2","P3","P4","P5","P6","P7","P8"]:        #SİYAH PİYON
        if harita[k+1][l] not in siyahlar:
            moveliste.append(newdata[str(l+1) + str(8-k-1)])
    elif e[0][1] in ["n1","n2","N1","N2"]:                            #ATLAR
        while k+1<=7 and l+1<=7:
            if harita[k+1][l+1] == "  ":
                moveliste.append(newdata[str(l+2)+str(8-k-1)])
                break
            else:
                break
        while k+1<=7 and l-1>=0:
            if harita[k+1][l-1] == "  ":
                moveliste.append(newdata[str(l)+str(8-k-1)])
                break
            else:
                break
        while k-1>=0 and l+1<=7:
            if harita[k-1][l+1] == "  ":
                moveliste.append(newdata[str(l+2) + str(8 - k + 1)])
                break
            else:
                break
        while k-1>=0 and l-1>=0:
            if harita[k-1][l-1] == "  ":
                moveliste.append(newdata[str(l) + str(8 - k + 1)])
                break
            else:
                break
        while k+2 <= 7 and l+1 <= 7:                                  #SAĞ ALT L 1
            if e[0][1] in beyazlar:
                if harita[k+2][l+1] not in beyazlar:
                    moveliste.append(newdata[str(l+2)+str(8-k-2)])
                    break
                else:
                    break
            else:
                if harita[k+2][l+1] not in siyahlar:
                    moveliste.append(newdata[str(l+2)+str(8-k-2)])
                    break
                else:
                    break
        while k+1<= 7 and l+2<=7:                                     #SAĞ ALT L 2
            if e[0][1] in beyazlar:
                if harita[k+1][l+2] not in beyazlar:
                    moveliste.append(newdata[str(l+3)+str(8-k-1)])
                    break
                else:
                    break
            else:
                if harita[k+1][l+2] not in siyahlar:
                    moveliste.append(newdata[str(l+3)+str(8-k-1)])
                    break
                else:
                    break
        while k-1>=0 and l+2<=7:                                      #SAĞ ÜST L 1
            if e[0][1] in beyazlar:
                if harita[k-1][l+2] not in beyazlar:
                    moveliste.append(newdata[str(l+3)+str(8-k+1)])
                    break
                else:
                    break
            else:
                if harita[k-1][l+2] not in siyahlar:
                    moveliste.append(newdata[str(l+3)+str(8-k+1)])
                    break
                else:
                    break
        while k-2>=0 and l+1<=7:                                      #SAĞ ÜST L 2
            if e[0][1] in beyazlar:
                if harita[k-2][l+1] not in beyazlar:
                    moveliste.append(newdata[str(l+2)+str(8-k+2)])
                    break
                else:
                    break
            else:
                if harita[k-2][l+1] not in siyahlar:
                    moveliste.append(newdata[str(l+2)+str(8-k+2)])
                    break
                else:
                    break
        while k - 2 >= 0 and l - 1 >= 0:                             #SOL ÜST L 1
            if e[0][1] in beyazlar:
                if harita[k - 2][l - 1] not in beyazlar:
                    moveliste.append(newdata[str(l) + str(8 - k +2)])
                    break
                else:
                    break
            else:
                if harita[k - 2][l - 1] not in siyahlar:
                    moveliste.append(newdata[str(l) + str(8 - k + 2)])
                    break
                else:
                    break
        while k - 1>=0 and l - 2 >= 0:                                     #SOL ÜST L2
            if e[0][1] in beyazlar:
                if harita[k-1][l-2] not in beyazlar:
                    moveliste.append(newdata[str(l-1)+str(8-k+1)])
                    break
                else:
                    break
            else:
                if harita[k-1][l-2] not in siyahlar:
                    moveliste.append(newdata[str(l-1)+str(8-k+1)])
                    break
                else:
                    break
        while k+1 <= 7 and l-2 >= 0:                                      #SOL ALT L1
            if e[0][1] in beyazlar:
                if harita[k+1][l-2] not in beyazlar:
                    moveliste.append(newdata[str(l-1)+str(8-k-1)])
                    break
                else:
                    break
            else:
                if harita[k+1][l-2] not in siyahlar:
                    moveliste.append(newdata[str(l-1)+str(8-k-1)])
                    break
                else:
                    break
        while k+2 <= 7 and l-1 >= 0:
            if e[0][1] in beyazlar:
                if harita[k+2][l-1] not in beyazlar:
                    moveliste.append(newdata[str(l)+str(8-k-2)])
                    break
                else:
                    break
            else:
                if harita[k+2][l-1] not in siyahlar:
                    moveliste.append(newdata[str(l)+str(8-k-2)])
                    break
                else:
                    break
    elif e[0][1] in ["ki","KI"]:                                      #KINGLER
        while k+1 <= 7:                                               #AŞAĞI-KİNGLER
            if e[0][1] in beyazlar:
                if harita[k+1][l] not in beyazlar:
                    moveliste.append(newdata[str(l+1)+str(7-k)])
                    break
                else:
                    break
            else:
                if harita[k+1][l] not in siyahlar:
                    moveliste.append(newdata[str(l + 1) + str(7 - k)])
                    break
                else:
                    break
        while k-1 >= 0:                                                #YUKARI-KINGLER
            if e[0][1] in beyazlar:
                if harita[k-1][l] not in beyazlar:
                    moveliste.append(newdata[str(l + 1) + str(8-k+1)])
                    break
                else:
                    break
            else:
                if harita[k-1][l] not in siyahlar:
                    moveliste.append(newdata[str(l + 1) + str(9 - k)])
                    break
                else:
                    break
        while l+1 <= 7:                                                 #SAĞA KINGLER
            if e[0][1] in beyazlar:
                if harita[k][l+1] not in beyazlar:
                    moveliste.append(newdata[str(l + 2) + str(8-k)])
                    break
                else:
                    break
            else:
                if harita[k][l+1] not in siyahlar:
                    moveliste.append(newdata[str(l + 2) + str(8 - k)])
                    break
                else:
                    break
        while l-1 >= 0:                                                 #SOLA KINGLER
            if e[0][1] in beyazlar:
                if harita[k][l-1] not in beyazlar:
                    moveliste.append(newdata[str(l) + str(8 - k)])
                    break
                else:
                    break
            else:
                if harita[k][l-1] not in siyahlar:
                    moveliste.append(newdata[str(l) + str(8 - k)])
                    break
                else:
                    break
        while k+1 <= 7 and l+1 <= 7:                                 #SAĞALT KINGLER
            if e[0][1] in beyazlar:
                if harita[k+1][l+1] not in beyazlar:
                    moveliste.append(newdata[str(l + 2) + str(7-k)])
                    break
                else:
                    break
            else:
                if harita[k+1][l+1] not in siyahlar:
                    moveliste.append(newdata[str(l + 2) + str(7 - k)])
                    break
                else:
                    break
        while k-1 >= 0 and l+1 <= 7:                               #SAĞ ÜST KINGLER
            if e[0][1] in beyazlar:
                if harita[k-1][l+1] not in beyazlar:
                    moveliste.append(newdata[str(l + 2) + str(9 - k)])
                    break
                else:
                    break
            else:
                if harita[k-1][l+1] not in siyahlar:
                    moveliste.append(newdata[str(l + 2) + str(9 - k)])
                    break
                else:
                    break
        while k-1 >= 0 and l-1 >= 0:                                   #SOL ÜST KINGLER
            if e[0][1] in beyazlar:
                if harita[k-1][l-1] not in beyazlar:
                    moveliste.append(newdata[str(l) + str(9-k)])
                    break
                else:
                    break
            else:
                if harita[k-1][l-1] not in siyahlar:
                    moveliste.append(newdata[str(l) + str(9 - k)])
                    break
                else:
                    break
        while k+1 <= 7 and l-1>= 0:                                          #SOL ALT KINGLER
            if e[0][1] in beyazlar:
                if harita[k+1][l-1] not in beyazlar:
                    moveliste.append(newdata[str(l) + str(7 - k)])
                    break
                else:
                    break
            else:
                if harita[k+1][l-1] not in siyahlar:
                    moveliste.append(newdata[str(l) + str(7 - k)])
                    break
                else:
                    break
    elif e[0][1] in ["r1","r2","R1","R2","qu","QU","b1","b2","B1","B2"]:    #çoklu hareketler,vezir kale fil
        while e[0][1] in ["r1","r2","R1","R2","qu","QU"]:
            while 0 <= k-x <= 7:                                        #yukarı
                if harita[k-x][l] == "  ":
                    moveliste.append(newdata[str(l+1)+str(8-k+x)])
                    x += 1
                    if 0 > k-x:
                        break
                else:
                    if e[0][1] in ["r1","r2","qu"]:
                        if harita[k-x][l] in siyahlar:
                            moveliste.append(newdata[str(l + 1) + str(8 - k + x)])
                            break
                        elif harita[k - x][l] in beyazlar:
                            break
                    elif e[0][1] in ["R1","R2","QU"]:
                        if harita[k-x][l] in beyazlar:
                            moveliste.append(newdata[str(l + 1) + str(8 - k + x)])
                            break
                        elif harita[k - x][l] in siyahlar:
                            break
            x = 1
            while 0 <= k+x <= 7:                                      #aşağı
                if harita[k+x][l] == "  ":
                    moveliste.append(newdata[str(l+1)+str(8-k-x)])
                    x += 1
                    if k+x > 7:
                        break
                else:
                    if e[0][1] in ["r1","r2","qu"]:
                        if harita[k+x][l] in siyahlar:
                            moveliste.append(newdata[str(l + 1) + str(8 - k - x)])
                            break
                        elif harita[k + x][l] in beyazlar:
                            break
                    elif e[0][1] in ["R1","R2","QU"]:
                        if harita[k+x][l] in beyazlar:
                            moveliste.append(newdata[str(l + 1) + str(8 - k - x)])
                            break
                        elif harita[k + x][l] in siyahlar:
                            break
            x = 1
            while 0 <= l+x <= 7:                                #SAĞA
                if harita[k][l+x] == "  ":
                    moveliste.append(newdata[str(l+x+1)+str(8-k)])
                    x += 1
                    if l+x > 7:
                        break
                else:
                    if e[0][1] in ["r1","r2","qu"]:
                        if harita[k][l+x] in siyahlar:
                            moveliste.append(newdata[str(l + x + 1) + str(8 - k)])
                            break
                        if harita[k][l+x] in beyazlar:
                            break
                    if e[0][1] in ["R1","R2","QU"]:
                        if harita[k][l+x] in siyahlar:
                            break
                        if harita[k][l+x] in beyazlar:
                            moveliste.append(newdata[str(l + x + 1) + str(8 - k)])
                            break
            x = 1
            while 0 <= l-x <= 7:                                        #SOLA GİTME
                if harita[k][l-x] == "  ":
                    moveliste.append(newdata[str(l - x + 1) + str(8 - k)])
                    x += 1
                    if l-x < 0:
                        break
                else:
                    if e[0][1] in siyahlar:
                        if harita[k][l-x] in siyahlar:
                            break
                        elif harita[k][l-x] in beyazlar:
                            moveliste.append(newdata[str(l - x + 1) + str(8 - k)])
                            break
                    elif e[0][1] in beyazlar:
                        if harita[k][l-x] in siyahlar:
                            moveliste.append(newdata[str(l - x + 1) + str(8 - k)])
                            break
                        else:
                            break
            break
        x = 1
        while e[0][1] in ["b1","b2","B1","B2","qu","QU"]:       #ÇAPRAZLAR
            if e[0][1] in ["qu","QU","B1","B2"]:
                while 0 <= k+x <= 7 and 0 <= l+x <= 7:              #SAĞ ALT
                    if harita[k+x][l+x] == "  ":
                        moveliste.append(newdata[str(l+x+1) + str(8-k-x)])
                        x += 1
                        if k+x > 7 or l+x > 7:
                            break
                    else:
                        if e[0][1] in beyazlar:
                            if harita[k+x][l+x] not in beyazlar:
                                moveliste.append(newdata[str(l + x + 1) + str(8 - k - x)])
                                break
                            else:
                                break
                        else:
                            if harita[k+x][l+x] not in siyahlar:
                                moveliste.append(newdata[str(l + x + 1) + str(8 - k - x)])
                                break
                            else:
                                break
            if e[0][1] in ["qu","QU","b1","b2"]:
                x = 1
                while 0 <= k-x <= 7 and 0 <= l+x <= 7:              #SAĞ ÜST
                    if harita[k-x][l+x] == "  ":
                        moveliste.append(newdata[str(l+x+1) + str(8-k +x)])
                        x += 1
                        if 0 > k-x or l+x > 7:
                            break
                    else:
                        if e[0][1] in beyazlar:
                            if harita[k-x][l+x] not in beyazlar:
                                moveliste.append(newdata[str(l + x + 1) + str(8 - k + x)])
                                break
                            else:
                                break
                        else:
                            if harita[k-x][l+x] not in siyahlar:
                                moveliste.append(newdata[str(l + x + 1) + str(8 - k + x)])
                                break
                            else:
                                break
            if e[0][1] in ["qu","QU","b1","b2"]:
                x = 1
                while 0 <= k-x <= 7 and 0 <= l-x <= 7:              #SOL ÜST
                    if harita[k-x][l-x] == "  ":
                        moveliste.append(newdata[str(l-x+1) + str(8-k +x)])
                        x += 1
                        if 0 > k-x or 0 > l-x:
                            break
                    else:
                        if e[0][1] in beyazlar:
                            if harita[k-x][l-x] not in beyazlar:
                                moveliste.append(newdata[str(l - x + 1) + str(8 - k + x)])
                                break
                            else:
                                break
                        else:
                            if harita[k-x][l-x] not in siyahlar:
                                moveliste.append(newdata[str(l - x + 1) + str(8 - k + x)])
                                break
                            else:
                                break
            if e[0][1] in ["qu","QU","B1","B2"]:
                x = 1
                while 0 <= k+x <= 7 and 0 <= l-x <= 7:              #SOL ALT
                    if harita[k+x][l-x] == "  ":
                        moveliste.append(newdata[str(l-x+1) + str(8-k -x)])
                        x += 1
                        if k-x > 7 or 0 > l-x:
                            break
                    else:
                        if e[0][1] in beyazlar:
                            if harita[k+x][l-x] not in beyazlar:
                                moveliste.append(newdata[str(l - x + 1) + str(8 - k - x)])
                                break
                            else:
                                break
                        else:
                            if harita[k+x][l-x] not in siyahlar:
                                moveliste.append(newdata[str(l - x + 1) + str(8 - k - x)])
                                break
                            else:
                                break
                break
            break
for e in commands:
    if e[0][0] == "initialize":
        initialize()
    elif e[0][0] == "move":
        moveliste = []
        movelist()
        if e[0][2] in moveliste:
            temp = list(data[e[0][2]])
            p = int(temp[0]) #2
            n = int(temp[1]) #3
            if harita[8-n][p-1] in ["ki","KI"]:
                print("> move",e[0][1],e[0][2])
                print("FAILED"),
            else:
                harita[8 - n][p - 1] = e[0][1]
                harita[k][l] = "  "
                print("> move", e[0][1], e[0][2])
                print("OK")
        else:
            print("> move",e[0][1],e[0][2])
            print("FAILED")
    elif e[0][0] == "showmoves":
        moveliste= []
        showmoves()
    elif e[0][0] == "print":
        print("> print")
        print("-----------------------")
        for satir in harita:
            print(*satir)
        print("-----------------------")
    elif e[0][0] == "exit":
        print("> exit")
        exit()












